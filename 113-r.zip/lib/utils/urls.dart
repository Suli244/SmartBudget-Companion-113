class DocFFSmartBudget {
  static const String prPol =
      'https://www.termsfeed.com/live/d201cb4d-8e0d-43df-a6a0-cd46f12c9b2f';
  static const String terUse =
      'https://www.termsfeed.com/live/8117cf67-ca3d-4525-b2f7-b6bc93a15ddc';
  static const String supporto = 'https://forms.gle/cb5uWeMj35iinbSYA';
}
