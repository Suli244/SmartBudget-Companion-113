import 'package:intl/intl.dart';

class AppDateFromat {
  static DateFormat dateFormat = DateFormat('dd.MM');
}
